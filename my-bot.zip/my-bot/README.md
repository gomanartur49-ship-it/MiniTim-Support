# MiniTim Support Bot

Telegram-бот службы поддержки MiniTim (Python 3.11, aiogram 3).

- /start — меню: Играть, Правила, Поддержка
- Вопросы игроков пересылаются админам в лс, админ отвечает реплаем

Запуск: `BOT_TOKEN=... python main.py`
